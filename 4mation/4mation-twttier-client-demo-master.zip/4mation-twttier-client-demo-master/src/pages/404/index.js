import React from 'react';
import { Container } from 'reactstrap';

export default () => {
  return (
    <Container>
      <h1 className="text-center">404</h1>
    </Container>
  );
}
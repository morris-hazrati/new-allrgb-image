export default {
  API_BASE_URL: 'https://api.twitter.com/1.1',
  DATE_TIME_FORMAT: 'YYYY-MM-DD HH:mm:ss',
  TWITTER_DATE_TIME_FORMAT: 'ddd MMM D HH:mm:ss ZZ YYYY'
}